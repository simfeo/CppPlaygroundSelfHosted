// -*- C++ -*-
//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#ifndef _LIBCPP___CXX03___FUNCTIONAL_BINARY_NEGATE_H
#define _LIBCPP___CXX03___FUNCTIONAL_BINARY_NEGATE_H

#include <__cxx03/__config>
#include <__cxx03/__functional/binary_function.h>

#if !defined(_LIBCPP_HAS_NO_PRAGMA_SYSTEM_HEADER)
#  pragma GCC system_header
#endif

_LIBCPP_BEGIN_NAMESPACE_STD

template <class _Predicate>
class _LIBCPP_TEMPLATE_VIS binary_negate
    : public __binary_function<typename _Predicate::first_argument_type,
                               typename _Predicate::second_argument_type,
                               bool> {
  _Predicate __pred_;

public:
  _LIBCPP_HIDE_FROM_ABI explicit binary_negate(const _Predicate& __pred) : __pred_(__pred) {}

  _LIBCPP_HIDE_FROM_ABI bool operator()(const typename _Predicate::first_argument_type& __x,
                                        const typename _Predicate::second_argument_type& __y) const {
    return !__pred_(__x, __y);
  }
};

template <class _Predicate>
inline _LIBCPP_HIDE_FROM_ABI binary_negate<_Predicate> not2(const _Predicate& __pred) {
  return binary_negate<_Predicate>(__pred);
}

_LIBCPP_END_NAMESPACE_STD

#endif // _LIBCPP___CXX03___FUNCTIONAL_BINARY_NEGATE_H
